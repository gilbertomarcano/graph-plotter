import app


# Main class of the program
def main():
    app.start()
    
if __name__ == '__main__':
    main()



